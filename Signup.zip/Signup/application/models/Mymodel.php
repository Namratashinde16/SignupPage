<?php

class Mymodel extends CI_Model
{
	function _condtruct(){
		parent::_condtruct();
	}
	public function Insert_Registration_Data($data)   //inserting registration data 
	{
		// Query to check whether username already exist or not
		$condition = "user_name =" . "'" . $data['user_name'] . "'";
		$this->db->select('*');
		$this->db->from('registration');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 0) 
		{
			// Query to insert data in database
			$this->db->insert('registration',$data);
			if ($this->db->affected_rows() > 0) 
			{
				return true;
			}
			else
			{
				return false;

			}
		}
	}
	public function get_signin_info($data)
	{
		// echo "<pre>"; print_r($data);
		$condition = "user_email =" . "'" . $data['useremail'] . "' AND " . "password =" . "'" . md5($data['password']) . "'";
		// echo "<pre>"; print_r($condition);
		$this->db->select('*');
		$this->db->from('registration');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		// echo "<pre>"; print_r($query->result());die;
		if ($query->num_rows() == 1) 
		{
			//return true;
			return $query->result();

		} 
		else 
		{
			return false;
		}
	}

	
	
}