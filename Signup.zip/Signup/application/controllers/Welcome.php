<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct();

		// Load form validation library
		$this->load->library('form_validation');
		$this->load->model('Mymodel');
	}

	public function index()
	{
		$this->load->view('signin');
	}

	public function signup() 
	{
		$this->load->view('signup');    //Load signup form
	}
	
	public function registration()
	{
		// echo "<pre>"; print_r($_POST);die;
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST')   //form validation
		{
			$this->form_validation->set_error_delimiters('<span class="text-danger">*', '</span>'); 
			$this->form_validation->set_rules('Username', 'Username', 'trim|required'); 
			$this->form_validation->set_rules('Email', 'Email', 'trim|required'); 
			$this->form_validation->set_rules('Password', 'Password', 'trim|required'); 
			$this->form_validation->set_rules('Confirm_password', 'Confirm_password', 'trim|required'); 
			$this->form_validation->set_rules('gender', 'gender', 'trim|required'); 
			if($this->form_validation->run()== FALSE)
			{
				$this->data['error'] = validation_errors();
				$this->load->view('signup');
			}
			else
			{

				$data = array(
				'user_name' => $this->input->post('Username'),
				'user_email' => $this->input->post('Email'),
				'password' => md5($this->input->post('Password')),
				'confirm_password' => md5($this->input->post('Confirm_password')),
				'gender' => $this->input->post('gender')
				);
				$result = $this->Mymodel->Insert_Registration_Data($data); //send data to model for insertion 
				//echo "<pre>"; print_r($result);die;
				if ($result == 1) 
				{
					$this->session->set_flashdata('message', 'Register Successfully. Please use the same credentials for Sign In..!!!');
					$this->load->view('signin');
				}
				else
				{
					$this->session->set_flashdata('message', 'Username already exist..!!!');
					$this->load->view('signup');

				}
			
			}
		}
	}
	public function signin()        //for sign in 
	{
		// echo "<pre>"; print_r($_POST);//die;
		$this->form_validation->set_rules('Email', 'Email', 'trim|required'); 
		$this->form_validation->set_rules('Password', 'password', 'trim|required'); 
		// echo "<pre>"; print_r($this->form_validation->run());die;
		if ($this->form_validation->run() == FALSE) 
		{
			if(isset($this->session->userdata['logged_in']))
			{
				$this->load->view('userinfo_page');
			}
			else
			{
				$this->load->view('signin');
			}
		}
		else
		{
			$data = array(
				'useremail' => $this->input->post('Email'),
				'password' => $this->input->post('Password')
				);
			$result = $this->Mymodel->get_signin_info($data);
			
			if ($result != false) 
			{
				$session_data = array(
				'useremail' => $result[0]->user_email,
				'password' => $result[0]->password,
				'username' => $result[0]->user_name,
				'gender' => $result[0]->gender,
				);

				// Add user data in session
				$this->session->set_userdata('logged_in', $session_data);
				$this->load->view('userinfo_page');
				
			} 
			else 
			{
				
				$this->session->set_flashdata('message', 'Invalid Username or Password..!!');
				$this->load->view('signin');

			}

		}
	}
	public function signout()
	{
		$sess_array = array(
		'useremail' => '',
		'password' => '',
		'username' => '',
		'gender' => '',
		);

		$this->session->unset_userdata('logged_in', $sess_array);
		$this->session->set_flashdata('message', 'Successfully Logout..!!');
		$this->load->view('signin');

	}
}