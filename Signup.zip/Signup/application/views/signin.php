
<?php //echo base_url("common_assets/css/style.css");die; ?>
<!DOCTYPE html>
<head>
<title>Registration / Login form </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Registration / Login form Responsive Widget, Login forms,Flat Pricing tables,Flat Drop downs  Sign up Web forms, Login sign up Responsive web Forms," />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom CSS -->
<link href="<?php echo base_url("common_assets/css/style.css")?>" rel='stylesheet' type='text/css' />
<!-- font CSS --><!--
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<link href="//fonts.googleapis.com/css?family=Archivo+Black" rel="stylesheet">-->
<link href="//fonts.googleapis.com/css?family=Signika:300,400,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:400,700" rel="stylesheet">

<!--font CSS-->
<script src="<?php echo base_url("common_assets/js/jquery2.0.3.min.js");?>"></script>
</head>
<body class="dashboard-page">
    <div class="main-grid">
      <div class="agile-grids"> 
        <!-- validation -->
        <div class="grids">
          <div class="progressbar-heading grids-heading">
            <h2>registration / login form</h2>
          </div>
          
          <div class="forms-grids">
            <div class="forms3">
            <div class="w3agile-validation w3ls-validation">
              
              <?php if($this->session->flashdata('message'))
                    { ?>  
                      <div class="mydiv alert alert-success"><center><h4><?php echo $this->session->flashdata('message')?></center></h4>  
                      </div> 
              <?php } ?> 
              <div class="panel panel-widget agile-validation">
                <div class="validation-grids validation-grids-right login-form">
                  <div class="widget-shadow login-form-shadow" data-example-id="basic-forms"> 
                    <div class="input-info">
                      <h3>Login form :</h3>
                    </div>
                    <div class="form-body form-body-info">
                      <!-- <form data-toggle="validator" action= <?php echo base_url()."Welcome/signin"; ?> method="post"> -->
                      <?php $attributes = array('class' => 'form-inline', 'id' => 'case1','name' => 'case1', ' method'=> 'post');
                        echo form_open('welcome/signin'); ?>
                                         
                        <div class="form-group has-feedback">
                          <input type="email" class="form-control" name="Email" placeholder="Enter Your Email" data-error="Bruh, that email address is invalid" required="">
                          <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                        </div>
                        <div class="form-group">
                          <input type="password" data-toggle="validator" data-minlength="6" class="form-control" id="inputPassword1" name="Password" placeholder="Password" required="">
                        </div>
                          <div class="form-group">
                            <button class="btn btn-primary">Sign In</button>
                          </div>
                          <div class="clearfix"> </div>
                      <!-- </form> -->
                      <?php echo form_close(); ?>
                      <div class="">
                            <div class="input-info">
                              <label>
                                 <a href= <?php echo base_url()."index.php/Welcome/signup"; ?> class="text-center new-account">Create an account </a>
                              </label>
                              <div class="help-block with-errors"></div>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="clear"> </div>
            </div>
          </div>
        </div>
        <!-- //validation -->
      </div>
    </div>
    
    
    
    <script type="text/javascript" src="<?php echo base_url("common_assets/js/valida.2.1.6.min.js");?>"></script>
    <script type="text/javascript" >

      $(document).ready(function() {

        // show Valida's version.
        $('#version').valida( 'version' );

        // Exemple 1
        $('.valida').valida();

        

        // setup the partial validation
        $('#partial-1').on('click', function( ev ) {
          ev.preventDefault();
          $('#res-1').click(); // clear form error msgs
          $('form').validate('partial', '#field-1'); // validate only field-1
          $('form').validate('partial', '#field-1-3'); // validate only field-1-3
        });

      });

    </script>
    <!-- //input-forms -->
    <!--validator js-->
    <script src="<?php echo base_url("common_assets/js/validator.min.js");?>"></script>
    <!--//validator js-->

</body>
</html>
